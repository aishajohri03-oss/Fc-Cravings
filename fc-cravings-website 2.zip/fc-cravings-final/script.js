/* ============================================================
   FC CRAVINGS — script.js
   Dark luxury restaurant website
   ============================================================ */

/* LOADER */
window.addEventListener('load',()=>{ setTimeout(()=>document.getElementById('loader').classList.add('hidden'),2400); });

/* NAV */
document.addEventListener('keydown',e=>{ if(e.key==='Escape'){ closeMenu(); } });

/* MENU MODAL */
function openMenu(){
  document.getElementById('menu-modal').classList.add('open');
  document.body.style.overflow='hidden';
}
function closeMenu(){
  document.getElementById('menu-modal').classList.remove('open');
  document.body.style.overflow='';
}
function switchTab(id){
  document.querySelectorAll('.menu-category').forEach(c=>c.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
  document.getElementById('cat-'+id).classList.add('active');
  event.target.classList.add('active');
}

/* CURSOR */
const cur=document.getElementById('cursor'),ring=document.getElementById('cursor-ring');
let mx=0,my=0,rx=0,ry=0;
document.addEventListener('mousemove',e=>{ mx=e.clientX; my=e.clientY; cur.style.left=mx+'px'; cur.style.top=my+'px'; });
(function animRing(){ rx+=(mx-rx)*.12; ry+=(my-ry)*.12; ring.style.left=rx+'px'; ring.style.top=ry+'px'; requestAnimationFrame(animRing); })();
document.querySelectorAll('a,button,[onclick]').forEach(el=>{
  el.addEventListener('mouseenter',()=>{ cur.style.width='20px'; cur.style.height='20px'; ring.style.width='60px'; ring.style.height='60px'; ring.style.borderColor='rgba(122,0,0,.7)'; });
  el.addEventListener('mouseleave',()=>{ cur.style.width='12px'; cur.style.height='12px'; ring.style.width='40px'; ring.style.height='40px'; ring.style.borderColor='rgba(122,0,0,.4)'; });
});

/* CURSOR TRAIL */
const tc=document.getElementById('cursor-trail'),tCtx=tc.getContext('2d');
tc.width=window.innerWidth; tc.height=window.innerHeight;
window.addEventListener('resize',()=>{ tc.width=window.innerWidth; tc.height=window.innerHeight; });
const trail=[];
document.addEventListener('mousemove',e=>{ trail.push({x:e.clientX,y:e.clientY,life:1}); if(trail.length>25)trail.shift(); });
(function drawTrail(){ tCtx.clearRect(0,0,tc.width,tc.height); trail.forEach(p=>{ p.life-=.04; tCtx.beginPath(); tCtx.arc(p.x,p.y,2,0,Math.PI*2); tCtx.fillStyle=`rgba(122,0,0,${p.life*.35})`; tCtx.fill(); }); requestAnimationFrame(drawTrail); })();

/* PARTICLES */
const pc=document.getElementById('particles-canvas'),pCtx=pc.getContext('2d');
pc.width=window.innerWidth; pc.height=window.innerHeight;
window.addEventListener('resize',()=>{ pc.width=window.innerWidth; pc.height=window.innerHeight; initP(); });
let pts=[];
function initP(){ pts=[]; const n=Math.floor(window.innerWidth/25); for(let i=0;i<n;i++) pts.push({x:Math.random()*pc.width,y:Math.random()*pc.height,r:Math.random()*1.5+.3,vx:(Math.random()-.5)*.15,vy:(Math.random()-.5)*.1,o:Math.random()*.4+.05}); }
initP();
(function animP(){ pCtx.clearRect(0,0,pc.width,pc.height); pts.forEach(p=>{ p.x+=p.vx; p.y+=p.vy; if(p.x<0)p.x=pc.width; if(p.x>pc.width)p.x=0; if(p.y<0)p.y=pc.height; if(p.y>pc.height)p.y=0; pCtx.beginPath(); pCtx.arc(p.x,p.y,p.r,0,Math.PI*2); pCtx.fillStyle=`rgba(122,0,0,${p.o})`; pCtx.fill(); }); requestAnimationFrame(animP); })();

/* SCROLL REVEAL */
const obs=new IntersectionObserver(entries=>entries.forEach(e=>{ if(e.isIntersecting)e.target.classList.add('visible'); }),{threshold:.1,rootMargin:'0px 0px -50px 0px'});
document.querySelectorAll('.fade-in-section').forEach(el=>obs.observe(el));

/* PARALLAX */
window.addEventListener('scroll',()=>{ const sy=window.scrollY; const bg=document.querySelector('.hero-video-bg'); if(bg)bg.style.transform=`translateY(${sy*.35}px)`; });