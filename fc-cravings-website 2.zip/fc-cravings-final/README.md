# FC CRAVINGS — Official Website
**Dark luxury restaurant · Main Hyd Road · Near Iqbal Pump · Mirpurkhas**

---

## 📁 Project Structure

```
fc-cravings/
├── index.html              ← Main website
├── style.css               ← All styles & animations
├── script.js               ← Cursor, menu, particles, scroll
├── README.md               ← This file
├── netlify.toml            ← Auto Netlify config
└── assets/
    ├── images/
    │   ├── hero-bg.jpg     ← Hero background (pizza)
    │   ├── pizza.jpg       ← Pizza category card
    │   ├── burger.jpg      ← Burger category card
    │   ├── wrap.jpg        ← Wraps category card
    │   └── dessert.jpg     ← Dessert category card
    ├── fonts/              ← (Google Fonts loaded via CSS)
    └── icons/              ← SVG icons inline in HTML
```

---

## 🚀 Deploy on Netlify (Easiest — Free)

1. Go to → **https://netlify.com**
2. Sign up / Log in
3. Click **"Add new site"** → **"Deploy manually"**
4. Drag & drop the entire `fc-cravings` folder
5. ✅ Your site is LIVE in 30 seconds!

---

## 🐙 Deploy on GitHub Pages (Free)

1. Go to → **https://github.com** → New repository
2. Name it: `fc-cravings`
3. Upload all files from this folder
4. Go to **Settings → Pages → Branch: main → / (root) → Save**
5. ✅ Live at: `https://yourusername.github.io/fc-cravings`

---

## 📞 Contact Info (in website)

| Field    | Value                                    |
|----------|------------------------------------------|
| Phone    | 0310-3218960                             |
| WhatsApp | +92 310 3218960                          |
| Location | Main Hyd Road · Near Iqbal Pump · Mirpurkhas |

---

*Built with cinematic dark luxury aesthetic · FC Cravings 2025*
